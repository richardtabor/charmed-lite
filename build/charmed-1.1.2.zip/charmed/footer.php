<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #page div and all content after
 *
 * @package Charmed
 */
?>

	</div>
</div>

<?php wp_footer(); ?>

</body>
</html>